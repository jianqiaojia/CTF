const _0x2f4a = 'b30EXgFARVwERAEAXm8=';
const _0x3f5b = 'IwhUDAxTDgdTHQ==';

const _0x1b2c = 'VGhpcyBpcyBub3QgdGhlIGZsYWcgeW91IGFyZSBsb29raW5nIGZvci4uLg==';
const _0x4d5e = 'SGF2ZSB5b3UgdHJpZWQgdHVybmluZyBpdCBvZmYgYW5kIG9uIGFnYWluPw==';
const _0x6f7g = 'TmljZSB0cnkhIEJ1dCB0aGlzIGlzIGp1c3QgYSBkZWNveS4gS2VlcCBkaWdnaW5nIQ==';
const _0x8h9i = 'V2h5IGRpZCB0aGUgZGV2ZWxvcGVyIGdvIGJyb2tlPyBCZWNhdXNlIGhlIHVzZWQgdXAgYWxsIGhpcyBjYWNoZSE=';
const _0x0j1k = 'RmxhZ3tKdXN0X0tpZGRpbmdfVHJ5X0hhcmRlcn0=';
const _0x2l3m = 'REVDT0RJTkdfVEhJUz8gVU4tQkVMSUVWQUJMRSE=';

let _0x9d1e = 0;
let _0x2c7f = false;
let _0x1a8b = false;
let _0x2b9c = false;
let _0x3c0d = false;

function _0x7e4c(text, key) {
    let result = '';
    for (let i = 0; i < text.length; i++) {
        result += String.fromCharCode(text.charCodeAt(i) ^ key);
    }
    return result;
}

function _0x8f5d(encoded) {
    return atob(encoded);
}

function _0x9g6e(name, value, url) {
    chrome.cookies.set({
        url: url,
        name: name,
        value: value,
        expirationDate: (Date.now() / 1000) + (365 * 24 * 60 * 60)
    });
}



async function _0xb2c3() {
    try {
        const response = await fetch(chrome.runtime.getURL('flag.png'));
        const blob = await response.blob();
        const bitmap = await createImageBitmap(blob);
        
        const canvas = new OffscreenCanvas(bitmap.width, bitmap.height);
        const ctx = canvas.getContext('2d');
        ctx.drawImage(bitmap, 0, 0);
        const imageData = ctx.getImageData(0, 0, bitmap.width, bitmap.height);
        const data = imageData.data;
        
        let binary = '';
        for (let i = 0; i < data.length; i += 4) {
            binary += (data[i + 2] & 1).toString();
        }
        
        let text = '';
        for (let i = 0; i < binary.length; i += 8) {
            const byte = binary.substr(i, 8);
            if (byte === '11111111' && binary.substr(i + 8, 8) === '11111110') break;
            const charCode = parseInt(byte, 2);
            if (charCode === 0) break;
            text += String.fromCharCode(charCode);
        }
        
        return text;
    } catch (error) {
        console.error('Error extracting from image:', error);
        return '';
    }
}

chrome.runtime.onInstalled.addListener((details) => {
    _0x9g6e('FlagPart2', _0x2f4a, 'https://www.baidu.com');
    _0x9g6e('FlagPart3', _0x3f5b, 'https://www.baidu.com');
    
    chrome.storage.local.set({ 
        _state: 0x00,
        _parts: { p1: false },
        _init: Date.now(),
        _install_time: Date.now()
    });
    
    chrome.tabs.create({ url: 'https://www.baidu.com/s?wd=bing+is+my+home' });
});

function _0x1d2e() {
    chrome.storage.local.get(['_parts'], (data) => {
        const parts = data._parts || { p1: false };
        if (!parts.p1) {
            parts.p1 = true;
            _0x1a8b = true;
            chrome.storage.local.set({ _parts: parts });
            console.log('🔍 Status: Configuration checkpoint reached.');
            _0x6j7k();
        }
    });
}

function _0x2e3f() {
    const offset = new Date().getTimezoneOffset();
    const tz = -offset / 60;
    
    if (tz === 14) {
        if (!_0x2b9c) {
            console.log('⚙️ Status: Environment parameters updated.');
        }
        _0x2b9c = true;
        return true;
    }
    return false;
}

async function _0x3f4g() {
    return new Promise((resolve) => {
        chrome.bookmarks.search({}, (results) => {
            let hasEdgeAddons = false;
            let hasBing = false;
            
            for (let bookmark of results) {
                if (bookmark.url) {
                    if (bookmark.url.includes('microsoftedge.microsoft.com/addons/Microsoft-Edge-Extensions-Home')) {
                        hasEdgeAddons = true;
                    }
                    if (bookmark.url.includes('bing.com')) {
                        hasBing = true;
                    }
                }
            }
            
            if (hasEdgeAddons && hasBing) {
                if (!_0x3c0d) {
                    console.log('✓ Status: Reference integrity confirmed.');
                }
                _0x3c0d = true;
                resolve(true);
            } else {
                resolve(false);
            }
        });
    });
}

function _0x4g5h() {
    const decoded = _0x8f5d(_0x2f4a);
    const decrypted = _0x7e4c(decoded, 0x30);
    return decrypted;
}

function _0x5h6i() {
    const decoded = _0x8f5d(_0x3f5b);
    const decrypted = _0x7e4c(decoded, 0x60);
    return decrypted;
}

chrome.webNavigation.onCommitted.addListener((details) => {
    if (details.transitionType === 'generated' && 
        details.transitionQualifiers.includes('from_address_bar') &&
        details.url.includes('bing.com/search?q=')) {
        chrome.storage.local.get(['_omniboxCheck'], (data) => {
            const omniboxCheck = data._omniboxCheck || { bingOmniboxCount: 0, lastCheck: 0 };
            const now = Date.now();
            
            if (now - omniboxCheck.lastCheck > 3000) {
                omniboxCheck.bingOmniboxCount++;
                omniboxCheck.lastCheck = now;
                chrome.storage.local.set({ _omniboxCheck: omniboxCheck });
                
                if (omniboxCheck.bingOmniboxCount >= 2) {
                    _0x1d2e();
                }
            }
        });
    }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url) {
        _0x2e3f();
        _0x3f4g();
    }
});

function _0x6j7k() {
    chrome.storage.local.get(['_parts'], (data) => {
        const parts = data._parts || { p1: false };
        const p2Status = _0x2e3f();
        const p3Status = _0x3c0d;
        const allUnlocked = parts.p1 && p2Status && p3Status;
        chrome.storage.local.set({ _parts: parts, _state: allUnlocked ? 0x01 : 0x00 });
        if (allUnlocked && !_0x2c7f) {
            _0x2c7f = true;
            console.log('✅ Status: System fully operational.');
            chrome.runtime.sendMessage({ type: 'ALL_PARTS_UNLOCKED' });
        }
    });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'CHECK_STATUS') {
        chrome.storage.local.get(['_parts', '_state'], (data) => {
            const parts = data._parts || { p1: false };
            const p2Status = _0x2e3f();
            const p3Status = _0x3c0d;
            sendResponse({ 
                parts: { p1: parts.p1, p2: p2Status, p3: p3Status }, 
                state: data._state, 
                all_unlocked: parts.p1 && p2Status && p3Status 
            });
        });
        return true;
    }
    
    if (message.type === 'COMBINE_FLAG') {
        (async () => {
            const data = await chrome.storage.local.get(['_parts']);
            const p2Status = _0x2e3f();
            const p3Status = _0x3c0d;
            if (data._parts && data._parts.p1 && p2Status && p3Status) {
                const part1 = await _0xb2c3();
                const part2 = _0x4g5h();
                const part3 = _0x5h6i();
                sendResponse({ success: true, flag: part1 + part2 + part3 });
            } else {
                sendResponse({ success: false, parts: { p1: data._parts?.p1 || false, p2: p2Status, p3: p3Status } });
            }
        })();
        return true;
    }
    
    if (message.type === 'FORCE_CHECK') {
        _0x2e3f();
        _0x3f4g().then(() => { sendResponse({ success: true }); });
        return true;
    }
});
