let _parts = { p1: false, p2: false, p3: false };

function checkStatus() {
    chrome.runtime.sendMessage({ type: 'CHECK_STATUS' }, (response) => {
        if (!response) return;
        
        _parts = response.parts || { p1: false, p2: false, p3: false };
        
        const statusText = response.all_unlocked ? 'All Parts Unlocked!' : 'Challenge Active';
        const statusColor = response.all_unlocked ? '#00ff00' : '#ffaa00';
        
        document.getElementById('status').textContent = statusText;
        document.getElementById('status').style.color = statusColor;
        
        const unlockedCount = Object.values(_parts).filter(v => v).length;
        const progressText = 'Progress: ' + unlockedCount + '/3 parts';
        document.getElementById('message').textContent = progressText;
        document.getElementById('message').style.color = '#00aaff';
        
        updatePartsDisplay();
        
        document.getElementById('extract-btn').disabled = !response.all_unlocked;
    });
}

function updatePartsDisplay() {
    const container = document.getElementById('flag-container');
    
    let html = '<div style="margin: 15px 0; font-size: 14px;">';
    html += '<h3 style="margin-bottom: 10px; color: #667eea;">Challenge Parts:</h3>';
    
    html += '<div style="margin: 8px 0;">';
    html += _parts.p1 ? '✅ ' : '❌ ';
    html += '<strong>Part 1</strong>';
    html += '</div>';
    
    html += '<div style="margin: 8px 0;">';
    html += _parts.p2 ? '✅ ' : '❌ ';
    html += '<strong>Part 2</strong>';
    html += '</div>';
    
    html += '<div style="margin: 8px 0;">';
    html += _parts.p3 ? '✅ ' : '❌ ';
    html += '<strong>Part 3</strong>';
    html += '</div>';
    
    html += '</div>';
    
    container.innerHTML = html;
    container.classList.remove('hidden');
}

document.getElementById('extract-btn').addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'COMBINE_FLAG' }, (response) => {
        if (response && response.success) {
            displayFlag(response.flag);
        } else {
            const container = document.getElementById('flag-container');
            container.innerHTML = '<p style="color: #ff6600; margin-top: 10px;">❌ Not all parts unlocked</p>';
        }
    });
});

function displayFlag(flag) {
    const container = document.getElementById('flag-container');
    const html = '<div style="margin-top: 20px; padding: 15px; background: #1a1a2e; border: 2px solid #00ff00; border-radius: 5px;">' +
        '<h3 style="color: #00ff00; margin-bottom: 10px;">SUCCESS!</h3>' +
        '<p style="margin: 10px 0;"><strong>Flag:</strong></p>' +
        '<code style="display: block; background: #0f0f1e; padding: 10px; color: #00ff00; word-break: break-all; border-radius: 3px;">' + flag + '</code>' +
        '</div>';
    
    container.innerHTML = html;
    alert('Flag: ' + flag);
}

setInterval(checkStatus, 2000);
checkStatus();

